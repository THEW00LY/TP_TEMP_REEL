
#ifndef __OS_H
#define __OS_H

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "os_config_template.h"

/* Maximum number of tasks supported by the OS */
#ifndef OS_CONFIG_MAX_TASKS
#define OS_CONFIG_MAX_TASKS 5
#endif

/* Enable debug features */
//#define OS_CONFIG_DEBUG

/* Stack type */
typedef uint32_t os_stack_t;

/* Public API */

/* Initialize OS structures */
void os_init(void);

/* Initialize a task */
bool os_task_init(void (*handler)(void), os_stack_t *p_stack, uint32_t stack_size);

/* Start the OS scheduler */
bool os_start(uint32_t systick_ticks);

#endif