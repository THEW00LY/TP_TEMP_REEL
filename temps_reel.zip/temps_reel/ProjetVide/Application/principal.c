#include "stm32f10x.h"
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "os.h"
#include "os.c"

void dummy1() {
	
	while(1) {}
}

void dummy2() {
	
	while(1){}
}

void SysTick_Handler(void) {
	if (os_curr_task->sp == (unsigned int) dummy1){
		__set_PSP((unsigned int) dummy1);
	}else{
		__set_PSP((unsigned int) dummy2);
	}
}

int main ( void )
{
	//this config was here at start
	RCC->APB2ENR |= (0x01 << 2) | (0x01 << 3) | (0x01 << 4) ;
	
	GPIOA->CRL &= ~(0xF<<4) ;
	GPIOA->CRL |= (0x2<<4) ;
	
	//part 1
	//periodic systick activation
	SysTick->LOAD = 72000 -1;
	SysTick->VAL = 0;
	SysTick->CTRL = SysTick_CTRL_CLKSOURCE | SysTick_CTRL_ENABLE | SysTick_CTRL_TICKINT;
	
	//part 2
	//switching to unprivileged mode using control reg.
	int ctrl = __get_CONTROL () ;
	ctrl |= 0x3;
	__set_PSP((unsigned int) 0x20003500 );
	__set_CONTROL ( ctrl ) ;
	
	//part 3
	os_stack_t stack1[128];
	os_stack_t stack2[128];
	//static os_stack_t stack3[128];
	
	os_task_init(&dummy1, stack1, 1000);
	os_task_init(&dummy1, stack2, 1000);
	
	os_start(SystemCoreClock);
	
	while (1)
	{

	}
}
